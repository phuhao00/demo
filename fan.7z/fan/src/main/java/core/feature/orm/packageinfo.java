package core.feature.orm;

public class packageinfo {

}
