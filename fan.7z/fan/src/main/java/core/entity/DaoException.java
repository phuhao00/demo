package core.entity;

public class DaoException extends UserException {
	
	private long date = System.currentTimeMillis();

    public long getDate() {
        return date;
    }

}
