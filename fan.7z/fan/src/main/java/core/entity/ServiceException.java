package core.entity;

public class ServiceException extends UserException {

}
