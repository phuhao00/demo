package core.entity;

public class UserException extends RuntimeException {

}
