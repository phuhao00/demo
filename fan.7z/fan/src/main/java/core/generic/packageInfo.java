package core.generic;

public class packageInfo {

}
