package com.service;

import com.hu.Test.SpringTestCase;
public class UserServiceTest {

	SpringTestCase human =new SpringTestCase();

	
}
