package com.hu.Test;

public class SpringTestCase {

	

	public int t() {
		// TODO Auto-generated method stub
		return 0;
	}

	
}

